package fr.formation.DAO;

public interface IDAOChemin {

}
