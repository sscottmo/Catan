package fr.formation.DAO;

import fr.formation.Classe.Position;

public interface IDAOPosition extends IDAO<Position>{

}
