package fr.formation.DAO;

import fr.formation.Classe.Carte;

public interface IDAOCarte extends IDAO<Carte> {

}
