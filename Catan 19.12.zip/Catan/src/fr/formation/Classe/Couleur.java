package fr.formation.Classe;

public enum Couleur {
	Orange, Violet, Cyan, Marron
}
