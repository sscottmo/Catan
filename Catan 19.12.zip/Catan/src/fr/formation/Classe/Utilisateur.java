package fr.formation.Classe;

public class Utilisateur {
	private int id;
	private String nom;
	private Partie partie;
}
