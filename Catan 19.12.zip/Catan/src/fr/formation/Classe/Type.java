package fr.formation.Classe;

public enum Type {
	Vide, Bois, Argile, Minerai, Laine, Ble, Desert, Ocean, Port, PortArgile, PortBois, PortMinerai, PortLaine, PortBle
}
