package fr.formation.Classe;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Carte {
	private int id = 0;
	private CarteDev carteDev;
	private Joueur joueur;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public CarteDev getCarteDev() {
		return carteDev;
	}
	public void setCarteDev(CarteDev carteDev) {
		this.carteDev = carteDev;
	}
	
	
	


	
	
	
	
	
	
	
	
}
