package fr.formation.Classe;

import java.util.ArrayList;

public class Partie {
	private int id;
	private ArrayList<Joueur> joueurs;
	private ArrayList<Carte> pioche;
	private int bois;
	private int argile;
	private int laine;
	private int ble;
	private int minerai;
	private Position bandit;
}
