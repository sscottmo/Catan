package fr.formation.Classe;

public enum CarteDev {
	Chevalier, PointDeVictoire, ProgresRoute, ProgresDecouverte, ProgresMonopole
}
